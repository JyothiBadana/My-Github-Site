// script.js

// Show a welcome message in the console
console.log("Welcome to your GitHub Pages static site!");

// Optional: Add a little interaction
document.addEventListener("DOMContentLoaded", function () {
    const heading = document.querySelector("h1");
    heading.addEventListener("click", () => {
        alert("Thanks for visiting my site!");
    });
});
